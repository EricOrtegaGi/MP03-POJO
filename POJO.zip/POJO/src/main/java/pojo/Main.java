package pojo;

import pojo.model.InputOutput;
import pojo.model.Toyota;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static Toyota[] models = new Toyota[20];
    static Scanner ent = new Scanner(System.in);

    public static void main(String[] args) {
        InputOutput.read();
        int pos = 0;
        boolean func = true;
        try {
            while (func) {
                System.out.println("--------TOYOTA--------\n");
                System.out.print("Selecciona una opcio:\n\n" +
                        "1- Afetgir Model\n2- Eliminar model\n3- Veure models\n4- Modificar model\n5- Guardar\n6- Sortir \n\n----------------------\n");
                int seleccio = ent.nextInt();
                if (seleccio == 1) {
                    for (int i = 0; i < 1; i++) {
                        try {
                            System.out.println("Introdueix el model (Separacions amb guions):");
                            String model = ent.next();
                            System.out.println("Introdueix l'any del model (2000, 1999, 2022...):");
                            int any = Integer.parseInt(ent.next());
                            System.out.println("Introdueix la referencia del motor  (Separacions amb guions):");
                            String motor = ent.next();
                            System.out.println("Introdueix els litres del motor en format '1,0  2,0  1,5  2,5  ':");
                            double litros = ent.nextDouble();
                            System.out.println("Introdueix la cilindrada del motor (2000, 1500, 1200, 3000...):");
                            int cc = Integer.parseInt(ent.next());
                            System.out.println("Introdueix la cantitat de cilindros del motor:");
                            int cil = Integer.parseInt(ent.next());
                            System.out.println("Introdueix els la potencia en cv del coche:");
                            int hp = Integer.parseInt(ent.next());
                            System.out.println("Introdueix el tipus del motor (I: en linia, V: en V, B: Boxer, H: hybrid):");
                            char tipusmot = ent.next().charAt(0);
                            System.out.println("Introdueix 1: si el motor es turboalimentat o 2: si es atmosferic");
                            boolean turbo;
                            if (ent.nextInt() == 1) turbo = true;
                            else turbo = false;
                            Toyota nou = new Toyota(model, any, motor, litros, cc, cil, hp, tipusmot, turbo);
                            int j = 0;
                            for (; j < models.length &&
                                    models[j] != null &&
                                    models[j].getModel().compareToIgnoreCase(nou.getModel()) < 0; j++)
                                ;
                            if (j == models.length) System.out.println("No es poden afetgir mes models");
                            else {
                                int k = models.length - 1;
                                for (; k < models.length && j < k; k--)
                                    models[k] = models[k - 1];
                                models[j] = nou;
                            }
                        } catch (NumberFormatException e) {

                            System.out.println("Valor invalid");
                        }
                    }
                } else if (seleccio == 2) {
                    int delete;
                    if (models.length == 0) System.out.println("No hi han models per a eliminar");
                    else {
                        pos = 0;
                        System.out.println("Selecciona la posicio del model a eliminar: \n--------------------------------------------");
                        for (int i = 0; i < models.length && models[i] != null; i++) {
                            System.out.println(pos + ": " + models[i].mostrar());
                            pos++;
                        }
                        //Reordenem el vector al borrar el model seleccionat
                        try {
                            delete = ent.nextInt();
                            for (int i = delete + 1; i < models.length && models[i] != null; i++) {
                                models[i - 1] = models[i];
                            }
                            //Aqui busquem la ultima posicio no nula i la fem nula
                            if (models[delete] != null) {
                                for (int i = models.length - 1; i >= 0; i--) {
                                    if (models[i] != null) {
                                        models[i] = null;
                                        break;
                                    }
                                }
                            } else {
                                System.out.println("No hi ha res a esborrar aqui");
                                continue;
                            }
                            pos = 0;
                            System.out.println("Llista despres de eliminar el model:");
                            for (int i = 0; i < models.length && models[i] != null; i++) {
                                System.out.println(pos + ": " + models[i].mostrar());
                                pos++;
                            }
                            pos = 0;
                        } catch (ArrayIndexOutOfBoundsException e) {
                            System.out.println("No es una posicio valida");
                        }
                    }
                } else if (seleccio == 3) {
                    for (int i = 0; i < models.length && models[i] != null; i++) {
                        System.out.println(models[i].mostrar());
                    }
                } else if (seleccio == 4) {
                    //amb la variable modificar despres podrem canviar alguns dels parametres del objecte usan tambe els setters
                    int modificar;
                    pos = 0;
                    System.out.println("Selecciona la posicio del model a modificar \n-------------------------------------------");
                    for (int i = 0; i < models.length && models[i] != null; i++) {
                        System.out.println(pos + ": " + models[i].mostrar());
                        pos++;
                    }
                    //aqui utilitzarem un switch que tractara diferents tipus de setters dins de un try-catch per modificar el parametre dessitjat
                    while (true) {
                        try {
                            modificar = ent.nextInt();
                            System.out.println("Selecciona que vols modificar");
                            models[modificar].getAll();

                            switch (ent.nextInt()) {
                                case 1: {
                                    System.out.println("Model: ");
                                    models[modificar].setModel(ent.next());
                                    break;
                                }
                                case 2: {
                                    System.out.println("Any: ");
                                    models[modificar].setAny(Integer.parseInt(ent.next()));
                                    break;
                                }
                                case 3: {
                                    System.out.println("Motor: ");
                                    models[modificar].setMotor(ent.next());
                                    break;
                                }
                                case 4: {
                                    System.out.println("Litres (1,5  2,0  4,9...): ");
                                    models[modificar].setLitros(ent.nextDouble());
                                    break;
                                }
                                case 5: {
                                    System.out.println("cc: ");
                                    models[modificar].setCc(Integer.parseInt(ent.next()));
                                    break;
                                }
                                case 6: {
                                    System.out.println("Cilindros: ");
                                    models[modificar].setCilindros(Integer.parseInt(ent.next()));
                                    break;
                                }
                                case 7: {
                                    System.out.println("hp: ");
                                    models[modificar].setHp(Integer.parseInt(ent.next()));
                                    break;
                                }
                                case 8: {
                                    System.out.println("Tipus Motor (I, V, B, H): ");
                                    models[modificar].setTipusMotor(ent.next().charAt(0));
                                    break;
                                }
                                case 9: {
                                    System.out.println("1: Turboalimentat \n2: Atmosferic");
                                    if (ent.nextInt() == 1) {
                                        models[modificar].setTurbo(true);
                                        break;
                                    } else {
                                        models[modificar].setTurbo(false);
                                        break;
                                    }
                                }
                            }
                            models[modificar].mostrar();
                            System.out.println("Estas d'acord amb el canvi? \n1: Guardar\n2: No guardar encara");
                            int guardar = ent.nextInt();
                            if (guardar == 1) {
                                InputOutput.write();
                                break;
                            } else if (guardar == 2) break;
                        } catch (IndexOutOfBoundsException | NullPointerException e) {
                            System.out.println("Selecciona una posicio valida");
                        }
                    }
                } else if (seleccio == 5) {
                    InputOutput.write();
                } else if (seleccio == 6) {
                    func = false;
                }
            }
        } catch (InputMismatchException e) {
            System.out.println("Valor invalid, ha de ser una seleccio dels numeros del 1:6 del menu, tornaho a intentar");
        }
    }
}

