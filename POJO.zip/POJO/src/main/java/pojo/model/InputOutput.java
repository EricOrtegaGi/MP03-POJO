package pojo.model;

import java.io.*;
import static pojo.Main.models;

public class InputOutput {

    /**
     * classe CRUD per guardar informacio
     * @param f creacio de fitxer 'db'
     */
    public static File f = new File("models.db");
    /**
     * Aquest metode serveix per escriure els objectes que te el vector dins del fitxer
     */
    public static void write(){
        ObjectOutputStream w = null;
        try {
            w = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(f)));
            for (int i = 0; i < models.length && models[i]!=null; i++) {
                w.writeObject(models[i]);
            }
        } catch (IOException e) {
            System.out.println("Ha iagut un problema escribint les dades ");
            e.printStackTrace();
        }finally {
            try {
                w.close();
            } catch (IOException|NullPointerException e) {
                System.out.println("Ha iagut un problema al tancar el programa");
            }
        }
    }
    /**
     * Aquest metode llegeix el fitxer i plena el vector dels objectes que te guardats
     */
    public static void read(){
        if (f.exists()){
            ObjectInputStream r = null;
            try {
                int i = 0;
                r = new ObjectInputStream(new BufferedInputStream(new FileInputStream(f)));
                while (true){
                    try {
                        while (true){
                            Toyota model = (Toyota) r.readObject();
                            models[i] = model;
                            i++;

                        }
                    }catch (ClassNotFoundException | EOFException e){
                        break;
                    }
                }
            }catch (IOException ex) {
                System.out.println("Error en obrir el fitxer");
            }finally {
                try {
                    r.close();
                }catch (IOException e) {
                    System.out.println("Error en tancar el fitxer");
                }
            }
        }
    }
}
