package pojo.model;
import java.io.Serializable;
public class Toyota implements Serializable {
    //propietats de la classe --> definixen l'estat dels objectes

    private String model;
    private int any;
    private String motor;
    private double litros;
    private int cc;
    private int cilindros;
    private int hp;
    private char tipusMotor;
    private boolean turbo;

    /**
     * Constructor en forma de formulari per emplenar
     * @param model model coche
     * @param any any
     * @param motor referencia del motor
     * @param litros litros
     * @param cc cilindrada
     * @param cilindros cantitat de cilindros
     * @param hp cavalls
     * @param tipusMotor amb aquest parametre direm si es un motor de tipus en linia, en v, boxer o hybrid
     * @param turbo indicarem si el coche es atmosferic o turboalimentat
     */

    //Constructor formulari
    public Toyota(String model, int any, String motor, double litros, int cc, int cilindros,int hp, char tipusMotor, boolean turbo){
        this.model = model;
        this.any = any;
        this.motor = motor;
        this.litros = litros;
        this.cc = cc;
        this.cilindros = cilindros;
        this.hp = hp;
        this.tipusMotor = tipusMotor;
        this.turbo = turbo;
    }

    /**
     * Constructor que es pot cridar per crear un model buit
     */
    // Constructor default
    public Toyota(){
        model = "?";
        any = 0;
        motor = "?";
        litros = 0;
        cc = 0;
        cilindros = 0;
        hp = 0;
        tipusMotor = '?';
        turbo = false;
    }

    /**
     * Constructor on tansols ficant el model es fa un objecte amb tots els altres atributs nulls
     * @param model
     */
    //Constructor model
    public Toyota(String model){
        this.model = model;

    }

    /**
     * Metode per mostrar la informacio del nostre vector pojo
     * @return cadena de text que ens mostrara l'objecte de forma mes atractiva
     */
    //mostrar inline
    public String mostrar(){
        return "Model: "+model+", Any: "+any+", Motor: "+motor+", "
                +litros+", cc: "+cc+", cil: "+ cilindros+", cv: "+hp
                +", Motor(I:En linia, V o B:Boxer, H:Hybrid):"+tipusMotor+", "
                +(turbo?"Turboalimentat, ":"Atmosferic");
    }

    public String toString(){
        return "Model: "+model+", Any: "+any+", Motor: "+motor+", "
                +litros+", cc: "+cc+", cil: "+ cilindros+", cv: "+hp
                +", Motor(I:En linia, V o B:Boxer, H:Hybrid):"+tipusMotor+", "
                +(turbo?"Turboalimentat, ":"Atmosferic");
    }


    //Metodes Accessors:

    /**
     * cada un d'aquests metodes retornen els atributs que el seu nom indica
     * @return atributGetter
     */
    //-------------------- Getters -----------------------
    public String getModel() {
        return model;
    }
    public int getAny() {
        return any;
    }
    public String getMotor() {
        return motor;
    }
    public double getLitros() {
        return litros;
    }
    public int getCc() {
        return cc;
    }
    public int getCilindros() {
        return cilindros;
    }
    public int getHp() {
        return hp;
    }
    public char getTipusMotor() {
        return tipusMotor;
    }
    public boolean isTurbo() {
        return turbo;
    }

    // -------------------- getAll -------------------------
    public void getAll() {
        System.out.println("1: Model: "+getModel());
        System.out.println("2: del: "+getAny());
        System.out.println("3: Motor: "+getMotor());
        System.out.println("4: "+getLitros());
        System.out.println("5: "+getCc()+"cc");
        System.out.println("6: "+getCilindros()+" cil");
        System.out.println("7: "+getHp()+"cv");
        System.out.println("8: Motor en: "+getTipusMotor());
        System.out.println("9: "+(isTurbo()?"turboalimentat":"atmosferic"));
    }
    //--------------------- Setters ------------------------

    /**
     * Ficant el model es fa un objecte default
     * @param model
     */
    public void setModel(String model) {
        this.model = model;
    }
    public void setAny(int any) {
        this.any = any;
    }
    public void setMotor(String motor) {
        this.motor = motor;
    }
    public void setLitros(double litros) {
        this.litros = litros;
    }
    public void setCc(int cc) {
        this.cc = cc;
    }
    public void setCilindros(int cilindros) {
        this.cilindros = cilindros;
    }
    public void setHp(int hp) {
        if (hp<0) return;
        this.hp = hp;
    }
    public void setTipusMotor(char tipusMotor) {
        this.tipusMotor = tipusMotor;
    }
    public void setTurbo(boolean turbo) {
        this.turbo = turbo;
    }
}
